

import React from 'react';
import './App.css';


const Image = ({src , alt }) => (
  <div className="image-container">
    <img src={src} alt={alt} className="home-image" />
  </div>
);


const HomePage = () => {
  return (
    <div className="home-page">
      
      <header>
        <h1>Webtons library</h1>
      </header>

<section className="description">
        <p>
        Top 10 Popular Webtoons With Over 50 Million Views
        </p>
      </section>
 <section className="image-gallery">
        <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-123040-750x375.webp"
          alt="Sample Image 1"
    />
    <div className="home-page"/>
      <header>
        <h1> <a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#Popular_Webtoons_Hello_Baby">
            HELLO BABY
          </a>
           </h1>
      </header>
     <section className="description">
          <p>
          Gwen is a kind and passionate young woman with a tragic backstory. Her mother died when she was young, and her stepmother and stepsister treated her even worse with the demise of her father. Before dying, her father suggests she go on a cruise vacation with her best friend when her partner broke up with her to focus on his career instead. On the vacation, she meets Arthur, a handsome but lonely young man. Things escalate between them when they share their unfortunate fates. They end up hooking up, but Gwen runs away, afraid of the outcome. Fate brings them 2 years later, and they end up in a legal fight when Arthur finds out about his and Gwen’s child. Read Hello Baby to learn whether they can solve their differences.
          </p>
        </section>
     
         
        <Image
          src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-123400-750x375.webp"
          alt="Sample Image 2"
        />
        <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#The_Alpha_Kings_Claim">
        The_Alpha_Kings_Claim
          </a>
        </h1>
      </header>
        <section className="description">
          <p>
          Do you believe in supernatural creatures like werewolves, vampires, and witches? How would you feel if one day you were transported to a different realm when you touched a painting? The same thing happened with Serena in The Alpha King’s Claim. One rainy day, she buys an interesting painting while taking shelter in a painting shop. When she touched the painting at her home, she got transported to the realm where werewolves lived. Moreover, she ends up on the bed of the Alpha King Aero, who hates all women.
          </p>
        </section>
        
        <Image
          src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-123842-750x375.webp"
          alt="Sample Image 3"
        />
         <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#Popular_Webtoons_Bitten_Contract">
        Bitten_Contract
           </a>
        </h1>
      </header>
        <section className="description">
          <p>
          Do you believe vampires exist? What would your first reaction be if you crossed paths with a vampire? Would you be delighted, terrified, or unsure of how to act? Well, Chae-i certainly had an unusual reaction than the others. Chae-i is an actress who has been in the entertainment industry ever since she can remember. However, she is been having a hard time fitting in with other actors due to the extremely painful headaches she started having a little while ago. As a consequence of this, her professional life started deteriorating.Everyone started thinking of her as some stuck-up actress. However, one time, she gets bitten by Ijun, a top actor who is a vampire. Surprisingly, her headache vanishes for a week. Hence, she asks him to continue biting her to keep everything going smoothly. To her surprise, Ijun asks for a contractual relationship in return. Read the popular webtoon, Bitten Contract, to find out his motive behind asking Chae-i for a relationship
          </p>
        </section>
        <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-125252-750x375.webp"
        alt="Sample Image 4"
        div className="home-page"/>
        <header>
          <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#Tricked_into_Becoming_the_Heroines_Stepmother">
          Tricked_into_Becoming_the_Heroines_Stepmother
           </a>
          </h1>
        </header>
          <section className="description">
            <p>
            How would you feel if one day you woke up in the novel you wrote just after dying in the real world? Would you feel ecstatic to have a chance to live again? Or would you feel scared because of the uncertain possibilities and the danger lurking? Daisy is a woman with a kind yet strong personality. Following her death in the real world, she wakes up in the novel she wrote with her nine other friends just for fun. Unfortunately, her living conditions do not change much. However, one random day, she is arrested by the duke’s soldier for helping her friend out.
            </p>
          </section>
        
         <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/08/Screenshot-2024-05-28-192655-e1723318535608-750x375.png"
        alt="Sample Image 5"
        />
         <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#The_Guy_Upstairs">
        The_Guy_Upstairs
           </a>
        </h1>
      </header>
        <section className="description">
          <p>
          The Guy Upstairs follows Rosy, a college undergraduate who is an orphan and barely makes ends meet by working odd jobs. However, her life is not too tough, especially because of her best friend Hawa. She supported and trusted her when nobody else did. However, strangely enough, she hears weird sounds coming from the floor above. One random day she decides to check just for her peace of mind, but wait, why is there a dead body of a woman? Moreover, why is she being dragged by her neighbor upstairs?
          </p>
        </section>
         <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/08/Screenshot-2024-08-11-011235-750x375.png"
        alt="Sample Image 6"
        />
         <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#The_Runaway">
        The_Runaway
           </a>
        </h1>
      </header>
        <section className="description">
          <p>
          Paris is known as the city of love by the whole world. Would you consider going there freshly after a breakup? Jian is a beautiful young woman who works in the fashion industry. One day, she discovers that her new handsome boss is the person she had been hooked up with in France. She dismisses it, thinking that he probably does not remember her since it has been so long. However, she is proved wrong. On top of it all, he is extremely rude to her in the office but too nice when alone. Also, the new gay couple that shifted next door is quite interesting. Scroll the popular webtoon The Runaway to know what happens when Jian’s ex tries patching up things with her and why the handsome neighbor is too kind to her.
          </p>
        </section>
         <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-132459-750x375.webp"
        alt="Sample Image 7"
        />
         <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#Popular_Webtoons_Your_Smile_Is_A_Trap">
        Your_Smile_Is_A_Trap
           </a>
        </h1>
      </header>
        <section className="description">
          <p>
          Do you believe that people judge others based on their outer appearance? Have you ever been judged based on your looks? Kiyo is an ex-idol trainee who wants to live like a normal teenager. In this attempt, he starts living with his grandmother and enrolls in a new school. He even starts wearing ugly-looking glasses to hide his exceptional looks. There, he meets Lily, another victim of the same thing. People fear her and her father just because of their scary features, even though they are nice. However, Kiyu makes the same mistakes as others and judges Lily just like everyone else. Gradually, Kiyu realizes his mistake and the fact that Lily is really nice and kind. Read Your Smile Is A Trap to learn about their blossoming love and the obstacles they face.
          </p>
        </section>
         <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-133040-750x375.webp"
        alt="Sample Image 8"
        />
         <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#There_Must_Be_Happy_Endings">
        There_Must_Be_Happy_Endings
           </a>
        </h1>
      </header>
        <section className="description">
          <p>
          If you ever get a chance to go back and change things you regret now, would you do it? Yeonu is a young and beautiful woman married to Seonjae, a cold and handsome businessman. Her marriage was of convenience and hence there is no love between her and her husband. They tried running the marriage, but ultimately, Yeonu gave up, and they divorced. Due to a series of unfortunate events, Seonjae dies in front of her. However, fate gives her a second chance, and she vows to save Seonjae this time. Read There Must Be Happy Endings to find out whether or not Yeonu was able to save Seonjae and why Seonjae seems to be hiding several secrets.
          </p>
        </section>
         <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-133857-750x375.webp"
        alt="Sample Image 9"
        />
         <div className="home-page"/>
      <header>
        <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#Seasons_of_Blossom">
        Seasons_of_Blossom
           </a>
        </h1>
      </header>
        <section className="description">
          <p>
          The popular webtoon series Seasons of Blossom is a compilation of several individual stories that are all connected. It contains all four seasons: spring, summer, fall, and winter. Each season contains a different story and a different theme with different endings. It focuses majorly on school bullying and how much it can affect someone’s whole life. Despite it being based on high school students, the story has several serious events and a storyline with many variations. Check out this webtoon to learn about each story and their interlinked connections
          </p>
        </section>
         <Image
        src="https://animemangatoon.com/wp-content/uploads/2024/09/Screenshot-2024-09-16-134227-750x375.webp"
        alt="Sample Image 10"
        /> <div className="home-page"/>
        <header>
          <h1><a href="https://animemangatoon.com/popular-webtoons-with-over-fifty-million-views/#Popular_Webtoons_Romance_101">
          Romance_101
           </a>
          </h1>
        </header>
          <section className="description">
            <p>
            Are you an organized person who keeps track of every detail, disregarding how insignificant it may be, or are you a messy person who goes with the flow? Bareum is a very organized person who even maintains a diary detailing all her events and commitments. She has always had great marks and a clear record of what she wants to do in the future. However, one thing that she has not had any luck with is making a boyfriend. She decides to do things a little differently to achieve this goal and hence joins a programming club despite her planner being full. Fate has different plans in store for her. Read the popular webtoon Romance 101 to find out whether or not she was able to achieve this goaal.
        
            </p>
          </section>
      </section>
    </div>
  );
};

export default HomePage;
